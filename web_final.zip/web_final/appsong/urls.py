from django.urls import include, path, reverse, re_path
from . import views
from appsong.views import *
from django.http import HttpResponse
from django.conf import settings

app_name = 'appsong'
urlpatterns = [
    path('princ', views.gen_page_principale, name='page_princ'),
    path('chanson/<int:chanson_id>/', gen_page_chanson, name='chanson'),
    path('chanson/nouv/', gen_nouv_chanson, name='nouv_chanson'),
    path('chanson/<int:chanson_id>/modif/', gen_modif_chanson, name='modif_chanson'),
    path('modif_categorie', gen_modif_categories, name='modif_categorie'),
    path('categorie/nouv/', gen_nouv_categorie, name='nouv_categorie'),
    path('nouv_commentaire/<int:ligne>/<int:text_id>', gen_nouv_commentaire, name='nouv_commentaires'),
    path('nouv_commentaireV/', gen_nouv_commentaireV, name='nouv_commentairesV'),
    path('chanson-comment/modif_commentaire/<int:comment_id>/', gen_modif_commentaire, name='modif_commentaires'),
    path('gen_page_chanson_comment/<int:chanson_id>/<int:num_ligne>/<int:text_id>/', gen_page_chanson_comment, name='gen_page_chanson_comment'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
]
