from django.apps import AppConfig


class AppsongConfig(AppConfig):
    name = 'appsong'
