from django import forms
from .models import *
from django.forms.widgets import HiddenInput
from django.contrib.auth import get_user_model
from django.db.models import Q
CATEGORIES= [tuple([x,x]) for x in Categorie.objects.all()]
User=get_user_model()

class SaisieChansonForm(forms.Form):
    groupe   = forms.CharField(label='GROUPE',max_length=50)
    titre   = forms.CharField(label='TITRE',max_length=50)
    youtube   = forms.CharField(label='YOUTUBE',max_length=200)
    paroles = forms.CharField (label="PAROLES",widget=forms.Textarea(attrs={'cols': '90', 'rows': '10', 'class': 'saisie-paroles'}),required=False)
    #Groupes = forms.ModelChoiceField(label='Groupes', queryset=Groupes.objects.all().order_by('id'), empty_label=None)
    categorie=forms.CharField(label='Categorie', widget=forms.Select(choices=CATEGORIES))

class ModifChansonForm(forms.Form):
    groupe   = forms.CharField(label='groupe',max_length=50)
    titre   = forms.CharField(label='titre',max_length=50)
    youtube   = forms.CharField(label='youtube',max_length=200)
    paroles = forms.CharField (label="Paroles",widget=forms.Textarea(attrs={'cols': '90', 'rows': '10', 'class': 'saisie-paroles'}),required=False)


class SasieTexteForm(forms.Form):
    paroles= forms.CharField(label='groupe',max_length=5000000000000000)

class ModifCategorieForm(forms.Form):
    nom   = forms.CharField(label='nom', max_length=30)
    #categories   = forms.CharField(label='categories', max_length=30)
    #categ   = forms.CharField(label='categ', max_length=30)
    selec   = forms.BooleanField(label='Sélec.', required=False)
    cat_id = forms.IntegerField(widget=HiddenInput())
    #categ = forms.ModelChoiceField(label='CATEGORIES',queryset=Categ.objects.all().order_by('id'), empty_label=None)
class SaisieCategorieForm(forms.Form):
    nom   = forms.CharField(label='nom',max_length=50)
    categ = forms.ModelChoiceField(label='Catégories', queryset=Categ.objects.all().order_by('id'), empty_label=None)
    #Categories = forms.ChoiceField(label='Categories', required=False, choices=Categorie.CHOIX_CATEGORIES)

class ModifCommentairesForm(forms.Form):
    com_id = forms.IntegerField(widget=HiddenInput())
    commentaire = forms.CharField (label="Commentaire",widget=forms.Textarea(attrs={'cols': '90', 'rows': '10', 'class': 'saisie-commentaires'}),required=True)

class SaisieCommentairesVForm(forms.Form):
    chanson   = forms.ModelChoiceField(label='Chanson',queryset=Chanson.objects.all().order_by('id'), empty_label=None)
    num_ligne   = forms.IntegerField(label='num_ligne')
    #commentaire   = forms.CharField(label='commentaire',max_length=50000000000)
    commentaire = forms.CharField (label="Commentaire",widget=forms.Textarea(attrs={'cols': '90', 'rows': '10', 'class': 'saisie-commentaires'}),required=False)

class SaisieCommentairesForm(forms.Form):
    commentaire = forms.CharField (label="Commentaire",widget=forms.Textarea(attrs={'cols': '90', 'rows': '10', 'class': 'saisie-commentaires'}),required=False)

#
class UserCreationForm(forms.ModelForm):
    password1=forms.CharField(label='Mot de passe', widget=forms.PasswordInput)
    password2=forms.CharField(label='Confirmation', widget=forms.PasswordInput)

    class Meta:
        model=User
        fields=['username', 'email']

    def clean_password(self):
        password1=self.cleaned_data.get('password1')
        password2=self.cleaned_data.get('password2')
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError('Les mots de passe doivent être similaires')
        return password2

    def save(self, commit=True):
        user=super(UserCreationForm, self).save(commit=False)
        user.set_password(self.cleaned_data['password1'])

        if commit:
            user.save()
        return user


class UserLoginForm(forms.Form):
    query=forms.CharField(label='Pseudo / Email')
    password=forms.CharField(label='Mot de passe', widget=forms.PasswordInput)

    def clean(self, *args, **kwargs):
        query=self.cleaned_data.get('query')
        password=self.cleaned_data.get('password')
        user_qs_final=User.objects.filter(Q(username__iexact=query) |
                                          Q(email__iexact=query)
                                      ).distinct()
        if not user_qs_final.exists() and user_qs_final.count !=1:
            raise forms.ValidationError("L'utilisateur n'existe pas")
        user_obj=user_qs_final.first()
        if not user_obj.check_password(password):
            raise forms.ValidationError("Incorrect")
        self.cleaned_data['user_obj']=user_obj
        return super(UserLoginForm, self).clean(*args, **kwargs)
class FiltreMusiqueForm(forms.Form):
    musique=forms.CharField(label='Titre ou groupe', required=False,max_length=50)
    nb_max=forms.IntegerField(label='Nombre à afficher', required=False, min_value=1)
