# import json
from django.shortcuts import render
from django.http import HttpResponse
from django.urls import reverse
from appsong.models import *
from appsong.forms import *
from django.forms.formsets import formset_factory

from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, get_user_model, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages


# Create your views here.
###############################################################
#               La fonction gen_page_principale               #
###############################################################
def gen_page_principale(request):
    catalogue = Chanson.objects.all()
    categories = Categorie.objects.all()
    texte = Texte.objects.all()
    context = {
        'titre': 'Catalogue de chansons',
        'catalogue': catalogue,
        'categories': categories,
        # 'urls' : reverse ('appsong:demos_sessions'),

    }
    # print(catalogue)
    return render(request, 'appsong/principale.html', context)


###############################################################
#                 La fonction gen_page_chanson                #
###############################################################
def gen_page_chanson(request, chanson_id):
    chanson = Chanson.objects.get(id=chanson_id)
    try:
        texte = Texte.objects.get(chanson_id=chanson_id)
        txt = texte.paroles
        text_id = texte.id
        txtLines = txt.splitlines()

    except Texte.DoesNotExist as detail:
        print("Erreur :", detail)
        txtLines = "Désolé, paroles non disponibles..."
        text_id = None

    context = {
        'chanson': chanson,
        'lines': txtLines,
        'text_id': text_id,
        'url_top': reverse('appsong:page_princ'),
        # 'url' : reverse ('appsong:modif_chanson'),
        'num_youtube': chanson.youtube.replace('watch?v=', 'embed/')
    }
    return render(request, 'appsong/chanson.html', context)


###############################################################
#                 La fonction gen_nouv_chanson_comment               #
###############################################################
def gen_page_chanson_comment(request, chanson_id, num_ligne, text_id):
    chanson = Chanson.objects.get(id=chanson_id)
    try:
        texte = Texte.objects.get(chanson_id=chanson_id)
        txt = texte.paroles
        text_id = texte.id
        txtLines = txt.splitlines()

    except Texte.DoesNotExist as detail:
        print("Erreur :", detail)
        txtLines = "Désolé, paroles non disponibles..."
        text_id = None

    try:
        comment = Commentaires.objects.filter(id_paroles=text_id, num_ligne=num_ligne)
        commentaire = {}

        commentaire = comment

    except Commentaires.DoesNotExist as detail:
        print("Commentaire n'existe pas")
        commentaire = None

    context = {
        'commentaire': commentaire,
        'chanson': chanson,
        'lines': txtLines,
        'text_id': text_id,
        'url_top': reverse('appsong:page_princ'),
        'num_ligne': num_ligne,
        # 'url' : reverse ('appsong:modif_chanson'),
        'num_youtube': chanson.youtube.replace('watch?v=', 'embed/')
    }

    return render(request, 'appsong/chanson-comment.html', context)


###############################################################
#                 La fonction gen_nouv_chanson                #
###############################################################

def gen_nouv_chanson(request):
    context={
        'titre' : "Saisie d'une chanson",
        'request' : request,
        'retour': reverse('appsong:page_princ'),

    }

    if request.method=='POST' :
        form=SaisieChansonForm(request.POST)
        if form.is_valid() :
            groupe=form.cleaned_data['groupe']
            titre=form.cleaned_data['titre']
            youtube=form.cleaned_data['youtube']
            paroles=form.cleaned_data['paroles']
            categorie=form.cleaned_data['categorie']
            liste=Chanson.objects.filter(groupe__iexact=groupe)
            if len(liste)== 0:
                nouv=Chanson()
                nouv.groupe=groupe
                nouv.titre=titre
                nouv.youtube=youtube
                nouv.save()
                nouv_cat_id= Categorie.objects.get(nom=form.cleaned_data['categorie'])
                nouv.categorie.add(nouv_cat_id.id)
                texte=Texte(chanson_id=nouv.id)
                texte.paroles=paroles
                texte.save()

                context['nc_message']='Titre '+titre+' : enregistré avec succès.'
            else :
                context['nc_message']='Erreur : titre déjà dans la base.'


    else:
        form=SaisieChansonForm()
    context['nc_form']=form

    return render(request, 'appsong/nouv_chanson.html', context)

###############################################################
#                 La fonction gen_modif_chanson               #
###############################################################
def gen_modif_chanson(request, chanson_id):
    # chanson=Chanson.objects.get(id=chanson_id)
    context = {
        'request': request,
        'retour': reverse('appsong:page_princ'),
    }
    try:
        chanson = Chanson.objects.get(id=chanson_id)
        texteExist = 0
        #
        try:
            texte = Texte.objects.get(chanson_id=str(chanson_id))
            texteExist = 1
        except Texte.DoesNotExist:
            texteExist = 0
            texte = Texte(chanson_id=chanson_id)
            # texte.id=chanson_id
            # texte.save()
        if request.method == 'POST':

            form = SaisieChansonForm(request.POST)
            if form.is_valid():
                groupe = form.cleaned_data['groupe']
                titre = form.cleaned_data['titre']
                youtube = form.cleaned_data['youtube']
                paroles = form.cleaned_data['paroles']
                liste = {}  # Chanson.objects.filter(groupe__iexact=groupe, titre__iexact=titre)
                if len(liste) == 0:
                    print(request.POST['action'])
                    if request.POST['action'] == "Modifier":
                        modif = Chanson.objects.get(id=chanson_id)
                        modif.groupe = groupe
                        modif.titre = titre
                        modif.youtube = youtube
                        modif.save()
                        if texteExist == 1:
                            texte.paroles = paroles
                            texte.save()
                        elif paroles != None:
                            # texte = Texte(chanson_id=chanson_id)
                            texte.paroles = paroles
                            # texte.id=chanson_id
                            texte.save()
                        else:
                            texte.delete()

                        context['sa_message'] = 'Cette chanson a été modifiée avec succès.'
                    else:
                        chanson.delete()
                        context['sa_message'] = 'Cette chanson a été supprimée avec succès.'
                else:
                    context['sa_message'] = 'Désolé : Cette chanson est déjà dans la base.'
        else:

            form = SaisieChansonForm({'groupe': chanson.groupe, 'titre': chanson.titre, 'youtube': chanson.youtube,
                                      'paroles': texte.paroles, })

        context['nc_form'] = form
    except Chanson.DoesNotExist:
        context['sa_message'] = "Désolé, cette chanson n'est pas dans la base"

    return render(request, 'appsong/modif_chanson.html', context)


###############################################################
#                La fonction gen_modif_categorie              #
###############################################################
def gen_modif_categories(request):
    context = {
        'titre': "Modification des categories",
        'request': request,  # pour debug
        'retour': reverse('appsong:page_princ'),
        'rtr': reverse('appsong:nouv_categorie'),
    }

    if request.method == 'POST':
        traiter_formset_modif_categories(context, request.POST)
    else:
        preparer_formset_modif_categories(context)

    return render(request, 'appsong/modif_categorie.html', context)


def preparer_formset_modif_categories(context):
    categories = Categorie.objects.all()
    data = {}
    i = 0
    for catego in categories:
        data.update({
            'ani-' + str(i) + '-cat_id': catego.id,
            'ani-' + str(i) + '-nom': catego.nom,
            'ani-' + str(i) + '-selec': False,
        })
        i += 1

    # Partie insérée dans le template avec {{sa_formset.management_form}}
    data.update({
        'ani-TOTAL_FORMS': str(i),
        'ani-INITIAL_FORMS': str(i),
        'ani-MAX_NUM_FORMS': '',
    })

    ModifCategoriesFormset = formset_factory(ModifCategorieForm)
    formset = ModifCategoriesFormset(data, prefix='ani')
    context['sa_formset'] = formset


def traiter_formset_modif_categories(context, data_post):
    ModifCategoriesFormset = formset_factory(ModifCategorieForm)
    formset = ModifCategoriesFormset(data_post, prefix='ani')

    # formset mémorisé maintenant dans context -> en cas d'erreur,
    # l'utilisateur verra les valeurs actuelles et les erreurs.
    context['sa_formset'] = formset

    if not formset.is_valid():
        context['sa_message'] = 'Erreur(s) dans le formulaire groupé.'
        return

    # Détection des boutons
    if 'b_modif' in data_post:
        modifier_categories_avec_formset(context, formset)
    elif 'b_suppr' in data_post:
        supprimer_categories_avec_formset(context, formset)
    else:
        context['sa_message'] = 'Erreur : bouton inconnu'


def modifier_categories_avec_formset(context, formset):
    n = 0
    for form in formset:
        cat_id = form.cleaned_data['cat_id']
        nom = form.cleaned_data['nom']
        selec = form.cleaned_data['selec']

        if selec:
            try:
                categorie = Categorie.objects.get(id=cat_id)
            except Categorie.DoesNotExist:
                context['sa_message'] = 'Erreur : categorie(s) inexistant.'
                return
            categorie.nom = nom
            categorie.save()
            n += 1

    if n == 0:
        context['sa_message'] = 'Aucune modification.'
    else:
        context['sa_message'] = str(n) + ' modification(s) enregistrée(s).'

    # On recrée le formset à partir de la BD modifiée en décochant les cases
    preparer_formset_modif_categories(context)


def supprimer_categories_avec_formset(context, formset):
    n = 0
    for form in formset:
        cat_id = form.cleaned_data['cat_id']
        selec = form.cleaned_data['selec']

        if selec:
            try:
                categories = Categorie.objects.get(id=cat_id)
                categories.delete()
            except Categorie.DoesNotExist:
                context['sa_message'] = 'Erreur : categorie inexistant.'
                return
            n += 1

    if n == 0:
        context['sa_message'] = 'Aucune suppression.'
    else:
        context['sa_message'] = str(n) + ' suppression(s) effectuée(s).'

    # On recrée le formset à partir de la BD modifiée en décochant les cases
    preparer_formset_modif_categories(context)


###############################################################
#                La fonction gen_nouv_categorie               #
###############################################################

def gen_nouv_categorie(request):
    context = {
        'titre': "Nouvel Categorie",
        'request': request,
        'retour': reverse('appsong:page_princ'),
    }
    if request.method == 'POST':
        form = SaisieCategorieForm(request.POST)
        if form.is_valid():
            nom = form.cleaned_data['nom']
            categ = form.cleaned_data['categ']
        liste = Categorie.objects.filter(nom__iexact=nom)
        if len(liste) == 0:
            # Enregistrement dans la base
            nouv = Categorie()
            nouv.nom = nom
            nouv.categ = categ
            nouv.save()
            context['sa_message'] = 'Categorie ' + nom + ' enregistré avec succès.'
        else:
            context['sa_message'] = 'Erreur : Categorie déjà dans la base.'
    else:
        form = SaisieCategorieForm()
    context['nc_form'] = form
    return render(request, 'appsong/nouv_categorie.html', context)


###############################################################
#              La fonction gen_nouv_commentairesV             #
###############################################################

def gen_nouv_commentaireV(request):
    context = {
        'titre': "Nouvel Commentaire",
        'request': request,
        'retour': reverse('appsong:page_princ'),
    }

    if request.method == 'POST':
        form = SaisieCommentairesVForm(request.POST)
        if form.is_valid():
            chanson = form.cleaned_data['chanson']
            num_ligne = form.cleaned_data['num_ligne']
            commentaire = form.cleaned_data[';lcommentaire']
            # liste=Commentaires.objects.filter(num_ligne__iexact=num_ligne,commentaire__iexact=commentaire, id_paroles__iexact=id_paroles)
            # if len(liste) == 0 :
            # Enregistrement dans la base
            nouv = Commentaires()
            nouv.commentaire = commentaire
            nouv.num_ligne = num_ligne
            try:
                texte = Texte.objects.get(chanson_id=chanson.id)
                nouv.id_paroles = texte
                nouv.save()
            except Texte.DoesNotExist:
                context['sa_message'] = 'Erreur: Paroles non existant pour cette chanson.'

            context['sa_message'] = 'Commentaire enregistré avec succès.'
    # else :
    # context['sa_message'] = 'Erreur : Commentaire déjà dans la base.'
    else:
        form = SaisieCommentairesVForm()
    context['nc_form'] = form
    return render(request, 'appsong/nouv_commentaire.html', context)


###############################################################
#              La fonction gen_modifier_commentaires             #
###############################################################

def gen_modif_commentaire(request, comment_id):
    context = {
        'titre': "Nouvel Commentaire",
        'request': request,
        'retour': reverse('appsong:page_princ'),
    }

    commentaire = Commentaires.objects.get(id=comment_id)

    if request.method == 'POST':
        form = ModifCommentairesForm(request.POST)
        if form.is_valid():
            if request.POST['action'] == "Modifier":
                com_id = form.cleaned_data['com_id']
                commentaire = form.cleaned_data['commentaire']
                # liste=Commentaires.objects.filter(num_ligne__iexact=num_ligne,commentaire__iexact=commentaire, id_paroles__iexact=id_paroles)
                # if len(liste) == 0 :
                # Enregistrement dans la bas
                modif = Commentaires.objects.get(id=com_id)
                if (commentaire != None):
                    modif.commentaire = commentaire
                    modif.save()
                    context['sa_message'] = 'Commentaire enregistré avec succès.'

            if request.POST['action'] == "Supprimer":
                com_id = form.cleaned_data['com_id']
                modif = Commentaires.objects.get(id=com_id)
                modif.delete()
                context['sa_message'] = 'Commentaire Supprimer avec succès.'
    # else :
    # context['sa_message'] = 'Erreur : Commentaire déjà dans la base.'
    else:
        form = ModifCommentairesForm({'com_id': comment_id, 'commentaire': commentaire.commentaire})
    context['nc_form'] = form
    return render(request, 'appsong/modif_commentaire.html', context)


###############################################################
#              La fonction gen_nouv_commentairesn            #
###############################################################

def gen_nouv_commentaire(request, ligne, text_id):
    context = {
        'titre': "Nouvel Commentaire",
        'request': request,
        'retour': reverse('appsong:page_princ'),
    }

    if request.method == 'POST':
        form = SaisieCommentairesForm(request.POST)
        if form.is_valid():
            commentaire = form.cleaned_data['commentaire']
            nouv = Commentaires()
            nouv.commentaire = commentaire
            paroles = Texte.objects.get(id=text_id)
            nouv.id_paroles = paroles
            nouv.num_ligne = ligne
            nouv.save()
            context['sa_message'] = 'Commentaire enregistré avec succès.'

    # else :
    # context['sa_message'] = 'Erreur : Commentaire déjà dans la base.'
    else:
        form = SaisieCommentairesForm()
    context['nc_form'] = form
    return render(request, 'appsong/nouv_commentaire.html', context)


###########################################################################


def register(request, *args, **kwargs):
    form = UserCreationForm(request.POST or None)
    if form.is_valid():
        form.save()
        return HttpResponseRedirect('/songs/login')
    context = {
        'form': form
    }

    return render(request, "appsong/register.html", context)


def login_view(request, *args, **kwargs):
    form = UserLoginForm(request.POST or None)
    if form.is_valid():
        user_obj = form.cleaned_data.get('user_obj')
        login(request, user_obj)
        return HttpResponseRedirect("/songs/princ")

    return render(request, "appsong/login.html", {'form': form})


def logout_view(request):
    logout(request)
    return render(request, "appsong/logout.html")









def gen_filtre_groupe (request) :
    context={
        'titre':'Catalogue de chansons',
        'cata' : Chanson.objects.all(),
        'categorie' : Categorie.objects.all(),
        'request':request,
    }
    if request.method=='GET' and len(request.GET)>0:
        form=FiltreMusiqueForm(request.GET)
        if form.is_valid():
            musique=form.cleaned_data['musique']
            nb_max=form.cleaned_data['nb_max']
            musiques=filtrer_musique(musique, nb_max)
            context['musiques']=musiques


    else:
        form=FiltreMusiqueForm()
    context['fg_form']=form
    return render(request,'appsong/principale.html',context)


def filtrer_musique(musique, nb_max):
    elts=Chanson.objects.filter(groupe__icontains=musique)|Chanson.objects.filter(titre__icontains=musique)
    liste=[]
    for elt in elts :
        liste += [elt]
        if nb_max != None and len(liste) >= nb_max :
            break

    return liste
