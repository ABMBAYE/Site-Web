from django.db import models
from django.contrib.auth.models import PermissionsMixin
from django.core.validators import RegexValidator

from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser
    )


# Create your models here.
class Chanson(models.Model):
    groupe = models.CharField(max_length=50, blank=True)
    titre = models.CharField(max_length=50, blank=True)
    #fichier = models.CharField(max_length=200, blank=True)
    youtube = models.URLField(max_length=50, blank=True)
    categorie = models.ManyToManyField('appsong.Categorie')
    #Groupes = models.ForeignKey('Groupes', on_delete=models.CASCADE, default=1)

    def __str__(self):
        return str(self.id)+'. '+self.titre+'-'+self.groupe

class Categorie(models.Model):
    nom = models.CharField(max_length=30, blank=True)
    categ = models.CharField(max_length=30, blank=True)
    #categ = models.ForeignKey('Categ', on_delete=models.CASCADE, default=1)
    #categories = models.CharField(max_length=2, choices=CHOIX_CATEGORIES,default='in')
    def __str__(self):
        return self.nom
    #classe = models.CharField(max_length=20, blank=True)
    #couleur = models.CharField(max_length=20, blank=True)



class Texte(models.Model):
    chanson = models.ForeignKey('appsong.Chanson', on_delete=models.CASCADE, blank=True, max_length=100000)
    paroles = models.TextField(max_length=300000000, blank=True)
    def __str__(self):
        return str(self.id)

class Groupes(models.Model):
    mode = models.CharField(max_length=40)
    def __str__(self):
        return self.mode

class Categ(models.Model):
    mode = models.CharField(max_length=40)
    def __str__(self):
        return self.mode

class Commentaires(models.Model):
    id_paroles = models.ForeignKey('appsong.Texte', on_delete=models.CASCADE, blank=True)
    num_ligne = models.IntegerField(blank=True, default=1)
    commentaire = models.TextField(max_length=300000000, blank=True)

#class Utilisateur(models.Model) :
 #   pseudo = models.CharField(max_length=50, blank=True)
  #  password = models.CharField(max_length=50, blank=True)

# class UserManager(BaseUserManager):
#     def create_user(self, username, email, password=None):
#         if not email:
#             raise ValueError('Il faut une adresse mail')
#         user = self.model(username=username,
#                           email=self.normalize_email(email)
#                           )
#         user.set_password(password)
#         user.save(using=self._db)
#         return user
#
#     def create_superuser(self, username, email, password=None):
#         user = self.create_user(
#             username, email, password=password
#         )
#         user.is_admin = True
#         user.is_staff = True
#         user.save(using=self._db)
#         return user
#
#
# class testUser(AbstractBaseUser, PermissionsMixin):
#     username = models.CharField(
#         max_length=300,
#         unique=True,
#         verbose_name='Pseudo'
#     )
#     email = models.EmailField(max_length=255, unique=True, verbose_name='Adresse email'
#                               )
#     is_admin = models.BooleanField(default=False)
#     is_staff = models.BooleanField(default=False)
#     objects = UserManager()
#
#     USERNAME_FIELD = 'username'
#     REQUIRED_FIELDS = ['email']
#
#     def __str__(self):
#         return self.email
#
#     def get_short_name(self):
#         return self.email
#
#     def has_perm(self, perm, obj=None):
#         "L'utilisateur a-t-il une permission spécifique ?"
#         return True
#
#     def has_module_perms(self, app_label):
#         "L'utilisateur a-t-il la permission de voir l'app 'app_label' ?"
#         return True
#
