from django.contrib import admin
from appsong.models import *
from django.contrib.auth.models import Group
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
# from .forms import UserCreationForm
# from .models import testUser

# Register your models here.
class ChansonAdmin(admin.ModelAdmin):
    list_display = ('groupe', 'titre', 'groupe', 'youtube')
    ordering = ('id',)
    list_max_show_all = 1000
    filter_horizontal = ('categorie',)
admin.site.register(Chanson, ChansonAdmin)

class CategorieAdmin(admin.ModelAdmin):
    list_display = ('id', 'nom')
    ordering = ('id',)
    list_max_show_all = 1000
admin.site.register(Categorie, CategorieAdmin)


class TexteAdmin(admin.ModelAdmin):
    list_display = ('chanson_id', 'paroles')
    ordering = ('id',)
    list_max_show_all = 1000
admin.site.register(Texte, TexteAdmin)


class GroupesAdmin(admin.ModelAdmin):
    list_display = ('id', 'mode')
    ordering = ('id',)
    list_max_show_all = 1000000
admin.site.register(Groupes, GroupesAdmin)

class CategAdmin(admin.ModelAdmin):
    list_display = ('id', 'mode')
    ordering = ('id',)
    list_max_show_all = 1000000
admin.site.register(Categ, CategAdmin)


class CommentairesAdmin(admin.ModelAdmin):
    list_display = ('id', 'num_ligne', 'commentaire','id_paroles')
    ordering = ('id',)
    list_max_show_all = 1000000
admin.site.register(Commentaires, CommentairesAdmin)


# class UserAdmin(BaseUserAdmin):
#     add_form = UserCreationForm
#
#     list_display = ('username', 'email', 'is_admin')
#     list_filter = ('is_admin',)
#
#     fieldsets = (
#         (None, {'fields': ('username', 'email', 'password')}),
#         ('Permissions', {'fields': ('is_admin',)})
#     )
#     search_fields = ('username', 'email')
#     ordering = ('username', 'email')
#     filter_horizontal = ()
#
